import React, {useEffect, useContext, useState} from 'react';
import {
  View,
  Text
} from 'react-native';


const EditProfileScreen = () => {

  return (
    <View >
        
        <Text>Edit Profile</Text>
      
    </View>
  );
};

export default EditProfileScreen;
